var express = require('express');
var router = express.Router();

var{ add_cat, add_sub }=require('../controller/controller')

router.post('/add_category',add_cat);
router.post('/add_sub_category/:cat_id',add_sub);

module.exports = router;
