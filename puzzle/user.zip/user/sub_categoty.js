var mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/puzzle_game')
    .then(() => console.log('Connected!'));

var add_sub = new mongoose.Schema({
    sub_category: {
        type: String
    },
    category_id:{
        type:String
    }

})

module.exports = mongoose.model('sub_category',add_sub)